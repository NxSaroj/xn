const { Events } = require('discord.js'); 

module.exports = {
    name: Events.ShardReady,
    async execute(shard) {
        console.log(`${shard.id} Is ready`);
    }
}