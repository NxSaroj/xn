const {
    SlashCommandBuilder,
    EmbedBuilder,
    PermissionsBitField,
  } = require("discord.js");
  const autoroleConfig = require("../../../models/misc/autoroleConfig");
  module.exports = {
    data: new SlashCommandBuilder()
      .setName("remove-autorole")
      .setDescription("remove a auto-role for guild")
      .addRoleOption((option) =>
        option
          .setName("role")
          .setDescription("the target role for autorole")
          .setRequired(true)
      )
      .setDMPermission(false),
      run: async ({ interaction }) => {
        await interaction.deferReply();
        const role = interaction.options.getRole('role');
        const isAlreadyDisabled = await autoroleConfig.findOne({ roleId: role.id, guildId: interaction.guild.id });
    
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return await interaction.editReply({
                content: '> **Required Permissions** <:xn_arrow:1206238725130952755> `Administrator`',
                ephemeral: true
            });
        }
    
        try {
            if (!isAlreadyDisabled) {
                return await interaction.editReply({
                    content: 'That role has not been configured for autorole',
                    ephemeral: true
                });
            } else {
                await autoroleConfig.findOneAndDelete({
                    roleId: role.id,
                    guildId: interaction.guild.id
                }).then(async () => {
                    const embed = new EmbedBuilder()
                        .setDescription(`> ${role} Has been removed from autorole`)
                        .setColor('White');
                    return await interaction.editReply({
                        embeds: [embed]
                    });
                }).catch(async (e) => {
                    console.error(e);
                    return await interaction.editReply({
                        content: 'DB error, try again later',
                        ephemeral: true
                    });
                });
            }
        } catch (err) {
            await interaction.deferReply({ ephemeral: true });
            console.error(__filename, err);
            return await interaction.editReply({
                content: 'Error while removing that role from autorole',
                ephemeral: true
            });
        }
    },


  }