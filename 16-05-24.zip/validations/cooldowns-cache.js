const cooldowns = new Map()
module.exports = {
    cooldowns
}